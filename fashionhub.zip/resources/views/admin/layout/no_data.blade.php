<div class="text-center ">
    <img src="{{ helper::image_path('image') }}" class="img-gluid rounded w-25" >
</div>