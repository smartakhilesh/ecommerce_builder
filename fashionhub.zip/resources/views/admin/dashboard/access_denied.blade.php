@extends('admin.layout.default')
@section('content')
    <div class="row mt-3">
        <div class="col-12">
            <div class="card border-0 mt-2">
                <div class="card-body d-flex justify-content-center align-items-center">
                   <h5>Access Denied</h5>
                </div>
            </div>
        </div>
    </div>
@endsection

