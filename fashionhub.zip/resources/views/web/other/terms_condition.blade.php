@extends('web.layout.default')
@section('contents')
<!-- BREADCRUMB AREA START -->

<section class="py-5 mb-5 bg-light">
    <div class="container">

        <nav aria-label="breadcrumb">
            <h2 class="breadcrumb-title mb-2">{{ trans('labels.terms_condition') }}</h2>
            
            <ol class="breadcrumb justify-content-center">

                <li class="{{ session()->get('direction') == 2 ? 'breadcrumb-item-rtl' : 'breadcrumb-item' }}"><a class="text-dark" href="{{ URL::to(@$vendordata->slug . '/') }}">{{ trans('labels.home') }}</a></li>

                <li class="text-muted {{ session()->get('direction') == 2 ? 'breadcrumb-item-rtl' : 'breadcrumb-item' }} active" aria-current="page">{{ trans('labels.terms_condition') }}</li>

            </ol>

        </nav>

    </div>
</section>

<!-- BREADCRUMB AREA END -->

<section class="terms-and-condition py-3">

    <div class="container">
        <h4 class="inner-title mb-4">Terms & Conditions</h4>
        <p>{!! $termscondition->terms_content !!}</p>
    </div>
    
</section>

@endsection
