<div class="col-lg-3 col-xxl-3 mb-4 mb-lg-0 ">
    <div class="card-v border py-3 rounded">
        <div class="title-and-image">
            <img src="{{ helper::image_path(@Auth::user()->image) }}" alt="" class="object-fit-cover img-fluid profile-img rounded-circle d-flex justify-content-center m-auto">
            <h5 class="text-dark mt-2 mx-3 text-center">{{ Auth::user()->name }}</h5>
        </div>
        <div class="user-list-saide-bar mt-4 bg-white rounded-1">
            <ul class="m-0">
                <a href="{{ URL::to($vendordata->slug . '/profile/') }}" class="settings-link">
                    <li class="list-unstyled border-0 text-dark my-2 py-3 px-3 d-flex align-items-center {{ request()->is($vendordata->slug.'/profile') ? 'account-active' : '' }}">
                        <i class="fa-light fa-user {{ session()->get('direction') == 2 ? 'ps-2' : 'pe-2' }}"></i>
                        <span class="px-2 d-block">
                            {{ trans('labels.edit_profile') }}
                        </span>
                    </li>
                </a>
                @if(@Auth::user()->google_id == "" && @Auth::user()->facebook_id == "")
                <a href="{{ URL::to($vendordata->slug . '/change-password/') }}" class="settings-link">
                    <li class="list-unstyled text-dark border-0 my-2 py-3 px-3 d-flex align-items-center {{ request()->is($vendordata->slug.'/change-password') ? 'account-active' : '' }}">
                        <i class="fa-light fa-lock {{ session()->get('direction') == 2 ? 'ps-2' : 'pe-2' }}"></i>
                        <span class="px-2 d-block">
                            {{ trans('labels.change_password') }}
                        </span>
                    </li>
                </a>
                @endif
                <a href="{{ URL::to($vendordata->slug . '/orders/') }}" class="settings-link ">
                    <li class="list-unstyled text-dark border-0 my-2 py-3 px-3 d-flex align-items-center {{ request()->is($vendordata->slug.'/orders') ? 'account-active' : '' }}">
                     <i class="fa-light fa-list-ol {{ session()->get('direction') == 2 ? 'ps-2' : 'pe-2' }}"></i>
                        <span class="px-2 d-block">
                                {{ trans('labels.orders') }}
                        </span>
                    </li>
                </a>
                <a href="{{ URL::to($vendordata->slug . '/favourite/') }}" class="settings-link ">
                    <li class="list-unstyled text-dark border-0 my-2 py-3 px-3 d-flex align-items-center {{ request()->is($vendordata->slug.'/favourite') ? 'account-active' : '' }}">
                    <i class="fa-light fa-heart {{ session()->get('direction') == 2 ? 'ps-2' : 'pe-2' }}"></i>
                    <span class="px-2 d-block">
                        {{ trans('labels.my_favorite_list') }}
                    </span>
                    </li>
                </a>
                <a href="{{ URL::to($vendordata->slug . '/deleteprofile/') }}" class="settings-link ">
                    <li class="list-unstyled text-dark border-0 my-2 py-3 px-3 d-flex align-items-center rounded">
                        <i class="fa-light fa-trash {{ session()->get('direction') == 2 ? 'ps-2' : 'pe-2' }}">
                        <span class="px-2 d-block">
                            </i>{{ trans('labels.delete_profile') }}
                        </span>
                    </li>
                </a>
                <a href="javascript:void(0)" onclick="statusupdate('{{ URL::to($vendordata->slug . '/logout') }}')" class="settings-link ">
                    <li class="list-unstyled text-dark border-0 my-2 py-3 px-3 d-flex align-items-center rounded">
                        <i class="fa-light fa-arrow-right-from-bracket {{ session()->get('direction') == 2 ? 'ps-2' : 'pe-2' }}">
                        <span class="px-2 d-block">
                            </i>{{ trans('labels.logout') }}
                        </span>
                    </li>
                </a>
            </ul>
        </div>
    </div>
</div>