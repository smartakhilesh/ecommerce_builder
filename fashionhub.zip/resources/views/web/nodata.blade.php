<div class="d-grid justify-items-center my-3">
    <img src="{{helper::image_path('nodata.svg')}}" alt="" class="w-25">
</div>