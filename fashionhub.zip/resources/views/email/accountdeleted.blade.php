<!DOCTYPE html>
<html>
<head>
    <title>{{$title}}</title>
</head>
<body>
    <div>
        <div style="background:#ffffff;padding:15px">
            <p>{{ trans('labels.dear') }} <b>{{$vendor_name}}</b>,</p>
            <p>{{ trans('labels.account_delete_msg') }}</p>
        </div>
    </div>
</body>
</html>