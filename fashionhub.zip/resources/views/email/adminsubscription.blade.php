<!DOCTYPE html>
<html>
<head>
    <title>{{$title}}</title>
</head>
<body>
    <div>
        <div style="background:#ffffff;padding:15px">
            <p>{{ trans('labels.dear') }} <b>{{$admin_name}}</b>,</p>

            <p>{{ trans('labels.new_subscription_title') }}</p>

            {{ trans('labels.name_of_subscriber') }}: <b>{{$vendor_name}}</b><br><br>
           {{ trans('labels.pricing_plan') }}: <b>{{$plan_name}}</b><br>
            {{ trans('labels.subscription_duration') }}: <b>{{$duration}}</b><br>
            {{ trans('labels.subscription_cost') }}: <b>{{$price}}</b><br><br>

            {{ trans('labels.payment') }}: <b>{{$payment_method}}</b><br>
            {{ trans('labels.transaction_id') }}: <b>{{$transaction_id}}</b><br>

            <p>{{ trans('labels.subscription_success_message') }}</p>

            <p>{{ trans('labels.best_regards') }},</p>

            {{$vendor_name}}<br>
            {{$vendor_email}}
        </div>
    </div>
</body>
</html>
