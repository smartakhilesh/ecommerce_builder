<!DOCTYPE html>
<html>
<head>
    <title>{{$title}}</title>
</head>
<body>
    <div>
        <div>
            <p>{{ trans('labels.dear') }} <b>{{ $vendorname }}</b>,</p>

            <p>{{ trans('labels.order_placed_vendor_message') }}</p>

            <p><b>{{ trans('labels.order_details') }}</b></p>

            {{ trans('labels.order_number') }} : <b>#{{$order_number}}</b><br>
            {{ trans('labels.date') }} : <b>{{$delivery_date}}</b><br>
            {{ trans('labels.grand_total') }} : <b>{{helper::currency_formate($grand_total,$vendorid)}}</b><br>

            <p>{{ trans('labels.sincerely') }},<br>
            {{$customer_name}}
            </p>
        </div>
    </div>
</body>
</html>
