<!DOCTYPE html>
<html>
<head>
    <title>{{$title}}</title>
</head>
<body>
    <div>
        <div style="background:#ffffff;padding:15px">
            <p>{{ trans('labels.dear') }} <b>{{$vendor_name}}</b>,</p>

            <p>{{trans('labels.banktransfer_rejected_message1')}} {{$payment_method}} {{ trans('labels.banktransfer_rejected_message2') }}</p>

            <p>{{ trans('labels.purchase_details') }}:</p>

            {{ trans('labels.pricing_plan') }}: <b>{{$plan_name}}</b><br>
            {{ trans('labels.payment') }}: <b>{{$payment_method}}</b><br>

            <p>{{ trans('labels.benefits_online_payment_system') }}</p>

            <p>{{ trans('labels.concern_message') }}</p>

            <p>{{ trans('labels.concern_message') }}</p>

            <p>{{ trans('labels.sincerely') }},</p>

            {{$admin_name}}<br>
            {{$admin_email}}
        </div>
    </div>
</body>
</html>
