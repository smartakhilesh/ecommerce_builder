<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Variation extends Model
{
    protected $table='variation';
    protected $fillable=['product_id','price','original_price','name'];
}