$('.type').on('change', function() {
    "use strict";
    var optionValue = $(this).find("option:selected").attr("value");
    if (optionValue) {
        $(".gravity").not("." + optionValue).hide();
        $(".gravity").not("." + optionValue).find('select').prop('required', false);
        $("." + optionValue).show();
        $("." + optionValue).find('select').prop('required', true);
    } else {
        $(".gravity").hide();
        $(".gravity").find('select').prop('required', false);
    }
}).change();