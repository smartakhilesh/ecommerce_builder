// common
$('.has_variation').on('change', function () {
    "use strict";
    check_variation_validation($(this).val())
});
$('.has_variation:checked').on('change', function () {
    "use strict";
    check_variation_validation($(this).val())
}).change();
function check_variation_validation(value) {
    "use strict";
    if (value == 1) {
        document.getElementById('price_row').style.display = 'none';
        if (location.href.includes("add") == true) {
            document.getElementById('variations').style.display = 'flex';
        } else {
            document.getElementById('variations').style.display = 'grid';
        }
        $('.variations, .btn-add-variations').show();
        $(".attribute, .variation , .variation_price , .variation_original_price").prop('required', true);
        $("#price").prop('required', false);
    } else {
        document.getElementById('price_row').style.display = 'flex';
        document.getElementById('variations').style.display = 'none';
        $('.variations, .btn-add-variations').hide();
        $(".attribute , .variation , .variation_price").prop('required', false);
        $("#price").prop('required', true);
        $('#more_variation_fields').html('');
        $('#edititem_fields').html('');
    }
}
function get_subcategories(ajaxurl,id){
    "use strict";
    $('#sub_category').html('<option><div class="spinner-border spinner-border-sm" role="status"><span class="sr-only">Loading...</span></div></option>');
    $.ajax({
        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
        url: ajaxurl,
        data: {id: id},
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status == 1) {
                var html = '<option value="" selected>' + $('select:first()').find('option:first()').html() + '</option>';
                $.each(response.data, function(key, value) {
                    var selected = '';
                    if ($('#sub_category').attr('data-old') == value.id) {
                        selected = 'selected';
                    }
                    html += '<option value="' + value.id + '" '+selected+' >' + value.name + '</option>';
                });
                $('#sub_category').html(html);
            } else {
                $('.emsg').html(wrong)
            }
        },
        error: function(e) {
            $('.emsg').html(wrong)
        }
    });
}
$(function () {
    $('#image').on('change', function () {
        "use strict";
        if (this.files) {
            var filesAmount = this.files.length;
            $('div.gallery').html('');
            $('div.gallery').addClass('row my-2');
            var n = 0;
            for (var i = 0; i < filesAmount; i++) {
                var reader = new FileReader();
                reader.onload = function (event) {
                    $($.parseHTML('<div>')).attr('class', 'col-lg-1 col-md-3 col-4 text-center').html('<img src="' + event.target.result + '" class="img-fluid w-auto rounded my-1">').appendTo('div.gallery');
                    n++;
                }
                reader.readAsDataURL(this.files[i]);
            }
        }
    });
});
// for add PRODUCT
var variation_row = 1;
function variation_fields(variation, price, original_price,qty) {
    "use strict";
    variation_row++;
    var divtest = document.createElement("div");
    divtest.setAttribute("class", "form-group mb-0 removeclass" + variation_row);
    divtest.innerHTML = '<div class="row variations"><div class="col-md-3"><div class="form-group"><input type="text" class="form-control variation" name="variation[]" placeholder="' + variation + '" required></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control numbers_only variation_price" name="variation_price[]" placeholder="' + price + '" required></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control numbers_only variation_original_price" name="variation_original_price[]" placeholder="' + original_price + '" value="0"></div></div><div class="col-md-2"><div class="form-group"><input type="text" class="form-control numbers_only variation_qty" name="variation_qty[]" placeholder="' + qty + '" required value="0"></div></div><div class="col-md-1 d-flex align-items-end"><div class="form-group"><button class="btn btn-outline-danger" type="button" onclick="remove_variation_fields(' + variation_row + ');"><i class="fa-sharp fa-solid fa-xmark"></i></button></div></div></div>';
    $('#more_variation_fields').append(divtest)
}
function remove_variation_fields(rid) {
    "use strict";
    $('.removeclass' + rid).remove();
}
$('#cat_id').on('change', function() {
    "use strict";
    get_subcategories($(this).attr('data-url'),$(this).val());
}).change();
// FOR EDIT PRODUCT
function addimage(product_id) {
    "use strict";
    $("#product_id").val(product_id);
    $("#addModal").modal('show');
}
function imageview(id, image) {
    "use strict";
    $("#img_id").val(id);
    $("#img_name").val(image);
    $("#editModal").modal('show');
}
$('#editcat_id').on('change', function() {
    "use strict";
    get_subcategories($(this).attr('data-url'),$(this).val());
});
function edititem_fields(variation, price, original_price,qty) {
    "use strict";
    if (!$('span').hasClass('hiddencount')) {
        $('#edititem_fields').prepend('<span class="hiddencount d-none">'+1+'</span>')
    }
    var editroom = $('span.hiddencount:last()').html();
    editroom++;
    var editdivtest = document.createElement("div");
    editdivtest.setAttribute("class", "form-group mb-0 editremoveclass" + editroom);
    editdivtest.innerHTML = '<input type="hidden" class="form-control" id="variation_id" name="variation_id[' + editroom + ']"><div class="row"><div class="col-md-3"><div class="form-group"><input type="text" class="form-control variation" name="variation[' + editroom + ']" placeholder="' + variation + '" required=""></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control numbers_only variation_price" name="variation_price[' + editroom + ']" placeholder="' + price + '" required=""></div></div><div class="col-md-3"><div class="form-group"><input type="text" class="form-control numbers_only variation_original_price" name="variation_original_price[' + editroom + ']" placeholder="' + original_price + '" value="0"></div></div><div class="col-md-2"><div class="form-group"><input type="text" class="form-control numbers_only variation_qty" name="variation_qty[' + editroom + ']" placeholder="' + qty + '" required="" value="0"></div></div><div class="col-md-1 d-flex align-items-end"><div class="form-group"><button class="btn btn-outline-danger" type="button" onclick="remove_edit_fields(' + editroom + ');"><i class="fa-sharp fa-solid fa-xmark"></i></button></div></div></div>';
    $('span.hiddencount:last()').html(editroom);
    $('#edititem_fields').append(editdivtest)
}
function remove_edit_fields(rid) {
    "use strict";
    $('.editremoveclass' + rid).remove();
}